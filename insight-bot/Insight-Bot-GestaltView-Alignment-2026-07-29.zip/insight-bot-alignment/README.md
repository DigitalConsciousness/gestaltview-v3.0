# Insight-Bot → GestaltView Runtime Alignment Package

This package is the adapter-first modernization layer for the dormant October-era Insight-Bot package.

## What this does

- Keeps Reddit/Devvit, Discord, and web as channel adapters.
- Moves runtime decisions to the current GestaltView runtime through one explicit HTTP contract.
- Preserves provenance and the user's original language.
- Prevents private embodiment/profile material from leaking into public channels.
- Adds a Supabase persistence seam for conversations, messages, and runtime events.
- Includes deterministic contract tests and an evaluation matrix for cross-provider verification.

## What this does not claim

- It does not pretend that the supplied dormant package is already aligned with the live GestaltView runtime.
- It does not replace Billy or expose Billy as a public scaffold entity.
- It does not make Reddit, Discord, or third-party model providers authoritative stores of user memory.
- It does not include secrets from the supplied archive.

## Apply order

1. Copy `src/shared/gestaltview/` into the Insight-Bot repository.
2. Copy `src/server/core/gestaltviewRuntimeClient.ts` and `src/server/routes/gestaltview.ts`.
3. Mount the route in `src/server/app.ts` and route platform handlers through the client.
4. Apply `supabase/migrations/20260729000000_insight_bot_runtime_bridge.sql` to the GestaltView Supabase project.
5. Set the server-only environment variables described in `docs/ENVIRONMENT.md`.
6. Run the contract tests before enabling public posting.

The current runtime URL and route must be confirmed against the live GestaltView repository before production deployment. The adapter therefore makes that endpoint configurable rather than hard-coding an unverified route.
