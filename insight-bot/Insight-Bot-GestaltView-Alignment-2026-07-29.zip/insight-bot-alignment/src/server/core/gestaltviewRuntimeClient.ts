import {
  assertRuntimeResponse,
  InsightRuntimeRequest,
  InsightRuntimeResponse,
  toPublicResponse,
} from '../../shared/gestaltview/contracts.js';

// The host Insight-Bot project already supplies Node typings. This narrow
// declaration keeps the overlay independently type-checkable for review tools.
declare const process: { env: Record<string, string | undefined> };

export interface RuntimeClientOptions {
  baseUrl: string;
  path: string;
  token?: string;
  timeoutMs?: number;
}

export class GestaltViewRuntimeError extends Error {
  constructor(message: string, public readonly status?: number) {
    super(message);
    this.name = 'GestaltViewRuntimeError';
  }
}

export function runtimeClientFromEnv(): GestaltViewRuntimeClient {
  const baseUrl = process.env.GESTALTVIEW_RUNTIME_URL;
  if (!baseUrl) throw new GestaltViewRuntimeError('GESTALTVIEW_RUNTIME_URL is not configured');
  return new GestaltViewRuntimeClient({
    baseUrl,
    path: process.env.GESTALTVIEW_RUNTIME_PATH || '/api/insight-bot/respond',
    token: process.env.GESTALTVIEW_RUNTIME_TOKEN,
    timeoutMs: Number(process.env.GESTALTVIEW_RUNTIME_TIMEOUT_MS || 25_000),
  });
}

export class GestaltViewRuntimeClient {
  constructor(private readonly options: RuntimeClientOptions) {}

  async respond(input: Omit<InsightRuntimeRequest, 'schemaVersion' | 'requestId'>): Promise<InsightRuntimeResponse> {
    const request: InsightRuntimeRequest = {
      schemaVersion: '2026-07-29',
      requestId: globalThis.crypto.randomUUID(),
      ...input,
    };
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.options.timeoutMs ?? 25_000);

    try {
      const response = await fetch(new URL(this.options.path, this.options.baseUrl), {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(this.options.token ? { authorization: `Bearer ${this.options.token}` } : {}),
          'x-gestaltview-request-id': request.requestId,
        },
        body: JSON.stringify(request),
        signal: controller.signal,
      });

      const body: unknown = await response.json().catch(() => undefined);
      if (!response.ok) throw new GestaltViewRuntimeError(`GestaltView runtime returned HTTP ${response.status}`, response.status);
      assertRuntimeResponse(body);
      return request.source.visibility === 'public' ? toPublicResponse(body) : body;
    } catch (error) {
      if (error instanceof GestaltViewRuntimeError) throw error;
      const message = error instanceof Error ? error.message : 'Unknown runtime transport failure';
      throw new GestaltViewRuntimeError(`GestaltView runtime request failed: ${message}`);
    } finally {
      clearTimeout(timeout);
    }
  }
}
