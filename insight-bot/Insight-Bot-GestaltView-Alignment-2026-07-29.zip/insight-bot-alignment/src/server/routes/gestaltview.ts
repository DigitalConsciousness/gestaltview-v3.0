import { Router, Request, Response } from 'express';
import { runtimeClientFromEnv, GestaltViewRuntimeError } from '../core/gestaltviewRuntimeClient.js';
import { InsightChannel, InsightMode, Visibility } from '../../shared/gestaltview/contracts.js';

const router = Router();

function nonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

router.post('/respond', async (req: Request, res: Response) => {
  const { message, channel = 'api', conversationId, externalMessageId, externalUserId, mode = 'respond' } = req.body ?? {};
  if (!nonEmptyString(message)) return res.status(400).json({ success: false, error: 'message is required' });
  if (!['reddit', 'discord', 'web', 'devvit', 'api'].includes(channel)) {
    return res.status(400).json({ success: false, error: 'unsupported channel' });
  }
  if (!['respond', 'reflect', 'capture', 'artifact'].includes(mode)) {
    return res.status(400).json({ success: false, error: 'unsupported mode' });
  }

  try {
    const runtime = runtimeClientFromEnv();
    const response = await runtime.respond({
      source: {
        channel: channel as InsightChannel,
        externalConversationId: conversationId,
        externalMessageId,
        externalUserId,
        visibility: 'public' as Visibility,
      },
      context: {
        originalText: message,
        mode: mode as InsightMode,
        publicContextOnly: true,
      },
      consent: {
        allowCapture: false,
        allowArtifactProposal: false,
        allowMemoryUse: false,
      },
    });
    return res.json({ success: true, data: response });
  } catch (error) {
    const status = error instanceof GestaltViewRuntimeError && error.status === 401 ? 502 : 503;
    return res.status(status).json({ success: false, error: 'GestaltView runtime unavailable', requestId: req.header('x-request-id') });
  }
});

export default router;
