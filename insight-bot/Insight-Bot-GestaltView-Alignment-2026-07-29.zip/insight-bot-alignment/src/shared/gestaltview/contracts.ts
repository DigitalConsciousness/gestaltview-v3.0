/**
 * Stable boundary between public channel adapters and the GestaltView runtime.
 * Keep this contract free of provider-specific and platform-specific types.
 */

export type InsightChannel = 'reddit' | 'discord' | 'web' | 'devvit' | 'api';
export type InsightMode = 'respond' | 'reflect' | 'capture' | 'artifact';
export type Visibility = 'public' | 'private' | 'internal';

export interface InsightSource {
  channel: InsightChannel;
  externalMessageId?: string;
  externalConversationId?: string;
  externalUserId?: string;
  subreddit?: string;
  guildId?: string;
  originUrl?: string;
  visibility: Visibility;
}

export interface InsightContext {
  /** The original words must remain available to the runtime. */
  originalText: string;
  displayName?: string;
  mode?: InsightMode;
  energyLevel?: number;
  userState?: string;
  publicContextOnly: boolean;
  requestedCapabilities?: string[];
}

export interface InsightRuntimeRequest {
  schemaVersion: '2026-07-29';
  requestId: string;
  source: InsightSource;
  context: InsightContext;
  consent: {
    allowCapture: boolean;
    allowArtifactProposal: boolean;
    allowMemoryUse: boolean;
  };
}

export interface RuntimeTrace {
  traceId: string;
  provider?: string;
  route?: string;
  generatedAt: string;
  uncertainty?: 'low' | 'medium' | 'high' | 'unknown';
  limitations?: string[];
}

export interface CaptureProposal {
  kind: 'capture';
  status: 'proposed';
  originalText: string;
  suggestedContext?: string;
  suggestedAnchor?: string;
  requiresUserApproval: true;
}

export interface ArtifactProposal {
  kind: 'artifact';
  status: 'proposed';
  title: string;
  body: string;
  sourceRequestId: string;
  requiresUserApproval: true;
}

export interface InsightRuntimeResponse {
  schemaVersion: '2026-07-29';
  requestId: string;
  content: string;
  trace: RuntimeTrace;
  actions?: Array<CaptureProposal | ArtifactProposal>;
  safety?: {
    crisisDetected: boolean;
    humanSupportRecommended?: boolean;
    publicPostingAllowed: boolean;
  };
}

export function assertRuntimeResponse(value: unknown): asserts value is InsightRuntimeResponse {
  if (!value || typeof value !== 'object') throw new Error('Runtime response is not an object');
  const response = value as Partial<InsightRuntimeResponse>;
  if (response.schemaVersion !== '2026-07-29') throw new Error('Unsupported runtime response schema');
  if (typeof response.requestId !== 'string' || typeof response.content !== 'string') {
    throw new Error('Runtime response is missing requestId or content');
  }
  if (!response.trace || typeof response.trace !== 'object' || typeof response.trace.traceId !== 'string') {
    throw new Error('Runtime response is missing trace metadata');
  }
}

export function toPublicResponse(response: InsightRuntimeResponse): InsightRuntimeResponse {
  return {
    ...response,
    actions: response.actions?.filter((action) => action.kind !== 'artifact'),
    safety: response.safety
      ? { ...response.safety, publicPostingAllowed: response.safety.publicPostingAllowed !== false }
      : undefined,
  };
}
