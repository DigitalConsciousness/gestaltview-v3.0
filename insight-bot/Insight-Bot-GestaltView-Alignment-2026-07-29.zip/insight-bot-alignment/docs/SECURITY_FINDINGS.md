# Security findings from the dormant archive

## Immediate action: rotate credentials

The supplied archive contains populated `.env` and `.env.local` files with
credentials for at least Hugging Face, Groq, Discord, and Reddit. The values are
not copied into this package. They should nevertheless be considered exposed:

1. Revoke and replace every populated provider key and bot token.
2. Remove `.env`, `.env.local`, and local editor environment files from Git history
   if they were ever committed to the remote repository.
3. Add secret scanning to CI and fail builds when assignment-form secrets appear.
4. Use server-side environment configuration only; do not use `VITE_*` for secrets.

## Release hygiene

Do not ship:

- `dist/` build output from the archive;
- `.snapshots/` or `.google/` bulk context mirrors;
- `actions-runner/` checked-in runtime artifacts;
- provider credentials, Reddit authorization material, or Discord tokens.

## Supabase boundary

The bridge migration enables RLS and removes `anon`/`authenticated` access. The
server integration should use the service role only from a trusted server/worker.
This follows Supabase's distinction between Postgres grants (whether a role can
reach an object) and RLS (which rows it can access):

https://supabase.com/docs/guides/api/securing-your-api
