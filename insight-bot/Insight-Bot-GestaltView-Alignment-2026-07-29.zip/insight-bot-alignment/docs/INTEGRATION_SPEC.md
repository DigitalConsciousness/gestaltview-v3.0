# Insight-Bot current-runtime integration specification

## Role

Insight-Bot is the public doorway into GestaltView across Reddit, Discord, Devvit,
and web. It is not a parallel memory system, a second Billy, or a place where
private embodiment profiles are copied into public prompts.

## Request path

```text
Reddit / Discord / Web / Devvit
  → channel adapter
  → normalized InsightRuntimeRequest
  → GestaltView runtime/API
  → governed response + trace + optional approval-gated proposals
  → channel-specific renderer
```

The runtime owns model routing, constitutional orientation, context selection,
memory use, artifact proposals, and uncertainty. Channel adapters own platform
authentication, rate limits, formatting, and posting.

## Current-era invariants

- Preserve the original user language; do not replace it with a generic summary.
- Separate fact, inference, uncertainty, and unresolved contradiction.
- Public channels receive public-safe context only.
- Capture and artifact creation are proposals requiring explicit approval.
- Never impersonate; represent the integration honestly as Insight-Bot within GestaltView.
- Crisis handling provides immediate human-support direction and does not claim clinical care.
- A provider failure is a runtime availability event, not a reason to fabricate certainty.

## Migration map

| Dormant surface | Current alignment | Action |
|---|---|---|
| `src/server/core/llmRouter.ts` | GestaltView runtime owns provider routing | Retain only as legacy fallback behind an explicit feature flag |
| `src/server/core/plkEngine.ts` | Runtime/context service owns PLK use | Send identifiers/approved context, not private corpus blobs |
| MongoDB `interactions` | Supabase bridge tables + runtime persistence | Migrate new writes first; backfill only after schema review |
| Redis rate limits/queues | Keep as channel infrastructure | Do not treat Redis as durable memory |
| Discord/Reddit handlers | Thin adapters | Normalize into the shared contract |
| Museum/exhibit prompt | Runtime orientation and embodiment layer | Remove duplicated, stale system prompt |
| `dist/` and archive snapshots | Build artifacts/history | Exclude from source and release packages |

## Completion gates

1. Health check can distinguish channel health from runtime health.
2. A request reaches the configured GestaltView endpoint with a trace ID.
3. A malformed runtime response is rejected rather than posted.
4. Public responses cannot contain artifact proposals or private context.
5. Provider choice is visible in server telemetry but not blindly trusted as a confidence score.
6. Reddit and Discord posting tests use mocked runtime responses.
7. Supabase migration applies with RLS enabled and no public table grants.
8. Secrets and historic `.env` files are absent from the release artifact.
