# Current component-library handoff

The supplied July component archive contains the right visual language for a future
Insight-Bot web surface, but it should not be copied wholesale into the Reddit or
Discord adapters.

Recommended reuse in the GestaltView web runtime:

- `components/capture/UniversalCaptureBar.tsx` for raw capture.
- `components/inner-world/InnerWorldRoom.tsx` and `InnerWorldInspector.tsx` for
  inspectable context and approval-gated routing.
- `components/rendering/GestaltRenderSurface.tsx` for validated artifact previews.
- `components/embodiment/PrivateInteriorSeal.tsx` and
  `GovernanceStatusBar.tsx` for clear public/private boundary signaling.
- `components/thinking/ThinkingAnimation.tsx` for provider-independent pending state.

Insight-Bot should receive a compact web “integration window” that uses these
components only after the runtime contract is working. The public channel adapters
should remain text-first, provenance-aware, and resilient to platform message limits.
