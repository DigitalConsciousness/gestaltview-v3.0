# Mounting the bridge in the dormant package

In `src/server/app.ts`, add the import beside the existing route imports:

```ts
import gestaltViewRouter from './routes/gestaltview.js';
```

Mount it before the legacy exhibit/consciousness routes:

```ts
app.use('/api/gestaltview', gestaltViewRouter);
```

The resulting public adapter endpoint is:

```text
POST /api/gestaltview/respond
```

Example request:

```json
{
  "message": "I have three directions and none feel finished.",
  "channel": "discord",
  "conversationId": "discord-thread-id",
  "externalMessageId": "discord-message-id",
  "externalUserId": "discord-user-id",
  "mode": "reflect"
}
```

During migration, leave `/api/exhibit/query` available for compatibility but do not
route new platform handlers through it. Its response contract and prompt are tied to
the old Museum-of-Impossible-Things abstraction.
