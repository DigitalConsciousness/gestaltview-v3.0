# Runtime bridge environment

Required on the server only:

```dotenv
GESTALTVIEW_RUNTIME_URL=https://<confirmed-live-runtime-host>
GESTALTVIEW_RUNTIME_PATH=/api/insight-bot/respond
GESTALTVIEW_RUNTIME_TOKEN=<server-only-token>
GESTALTVIEW_RUNTIME_TIMEOUT_MS=25000
```

For Supabase persistence, use the server-side URL and service role key only in the
server/worker environment. Never expose the service role key to React, Devvit UI,
Discord client code, or Reddit-facing bundles.

The supplied archive contains `.env` and `.env.local` files. They are not part of
this package. Treat any values that were ever committed or shared from those files
as compromised and rotate them before deployment.
