# Current-state audit — 2026-07-29

## Evidence inspected

- The supplied archive contains an `InsightBot_v1.7-main/Insight-Bot-v1.6-main`
  application with Reddit/Devvit, Discord, web, Express, Redis, MongoDB, and
  multi-provider LLM code.
- `package.json` still identifies the project as `museum-of-impossible-things`
  and points to the old `RogueFoxOne/Insight-Bot-v1.6` repository.
- The old runtime has duplicated provider/prompt paths in `llmRouter.ts`,
  `streamingRouter.ts`, and `anthropicClient.ts`.
- The old persistence path writes interactions to MongoDB and treats Redis as a
  queue/cache/rate-limit layer.
- The current supplied framework material describes GestaltView as a layered
  runtime/corpus/governance system with constitutional invariants, public/private
  boundaries, capture → inner-world → scaffold flows, and artifact validation.
- The supplied July component archive contains reusable capture, inner-world,
  rendering, embodiment, and governance components.

## Alignment judgment

Insight-Bot is important enough to preserve as a standalone integration entrypoint,
but it should not be “completed” by adding more logic to the dormant provider
router. The highest-leverage move is to make it a thin, observable adapter to the
current GestaltView runtime.

## Blocking unknowns before production

- Exact live GestaltView runtime host and endpoint path.
- Authentication mechanism and token audience for that endpoint.
- Current Supabase project/schema names for runtime subjects and memory/artifacts.
- Current production Reddit/Devvit and Discord application ownership/configuration.
- Whether public Insight-Bot conversations should be persisted by default or only
  after an explicit user action.

These are configuration/source-of-truth questions, not reasons to invent a second
runtime inside Insight-Bot.
