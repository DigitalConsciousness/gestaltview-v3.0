import { assertRuntimeResponse, toPublicResponse, type InsightRuntimeResponse } from '../src/shared/gestaltview/contracts.js';

describe('Insight-Bot runtime contract', () => {
  const response: InsightRuntimeResponse = {
    schemaVersion: '2026-07-29',
    requestId: 'request-1',
    content: 'Something is here, but the frame is not settled yet.',
    trace: { traceId: 'trace-1', generatedAt: new Date().toISOString() },
    actions: [
      { kind: 'artifact', status: 'proposed', title: 'Draft', body: '...', sourceRequestId: 'request-1', requiresUserApproval: true },
      { kind: 'capture', status: 'proposed', originalText: 'Original', requiresUserApproval: true },
    ],
  };

  it('accepts a complete runtime response', () => {
    expect(() => assertRuntimeResponse(response)).not.toThrow();
  });

  it('rejects an unversioned or malformed response', () => {
    expect(() => assertRuntimeResponse({ content: 'missing trace' })).toThrow();
  });

  it('removes artifact proposals from a public response', () => {
    const publicResponse = toPublicResponse(response);
    expect(publicResponse.actions).toHaveLength(1);
    expect(publicResponse.actions?.[0]?.kind).toBe('capture');
  });
});
