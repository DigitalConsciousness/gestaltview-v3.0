# GestaltView UI/UX Contract

**Status:** Implementation contract  
**Version:** 1.0.0  
**Applies to:** current runtime, GATE, Billy, Insight-Bot, Android, embodiment profiles, artifacts, and future collaborative projects

## Purpose

This contract turns the shared vibe into implementation decisions. It is intentionally platform-agnostic: React, Android Compose, Shopify, chat, and future clients should express the same grammar through their native primitives.

## Room shell

Every substantial surface is a room, station, exhibit, field manual, or clearly bounded operational place. Its shell should expose these regions in a predictable order:

1. **Identity** — name, purpose, current state.
2. **Orientation** — one plain sentence describing what can happen here.
3. **Presence** — Billy, an embodiment, orb, or relevant collaborator when applicable.
4. **Primary work surface** — conversation, capture, artifact, map, offer, or review.
5. **Decision rail** — accept, revise, defer, reject, export, retry, or return.
6. **Continuity cue** — what may be preserved, where it may go, and who decides.
7. **Recovery surface** — waiting, partial, blocked, failed, or unavailable state.

The shell may be visually atmospheric, compact, mobile-native, or storefront-oriented. It may not remove orientation, agency, continuity, or recovery.

## Shared journey

```text
arrive → understand → act → inspect → preserve or continue → return
```

This is a legibility model, not a mandatory funnel. Organic thought may remain parked. Intentional workflows may request a destination. The current stage must still be visible.

## Canonical component mapping

The existing component snapshot already contains most of the needed primitives. Prefer them as role-based building blocks before creating one-off equivalents.

| Role | Existing primitives |
|---|---|
| Atmosphere | `AuroraBackground`, `FogOverlay`, `BabylonAtmosphere`, `FloatingEmbers` |
| Presence | `Billy`, `BillyAvatar`, `BillyBabylon`, `EmbodimentOrb`, `DIPresenceIndicator` |
| Structure | `GlassCard`, `GlassPanel`, `RoomHeaderBar`, `RoomIdentityHeader`, `SectionLabel` |
| Capture | `UniversalCaptureBar`, `VoiceInput-Universal`, `VoiceMicButton`, `FileUploadDropzone` |
| Continuity | `Scaffold`, `InnerWorldTimeline`, `BucketDrops`, `RecapPanel`, `ContinuumTimeline3D` |
| Output | `ArtifactRenderer`, `GestaltRenderSurface`, `InnerWorldArtifact`, exhibit components |
| Governance | `GovernanceStatusBar`, `PrivateInteriorSeal`, `ProvenanceDisclosure`, `ValidationWall` |
| State | `RoomStateBadge`, `LoadingSpinner`, `NeuralThinkingIndicator`, `ErrorBoundary` |

The mapping is a translation aid, not a claim that every existing component is production-ready. Each implementation still passes the validation gates.

## State contract

Design these states before declaring a feature complete:

| State | Required visible information |
|---|---|
| Ready | purpose, scope, primary action |
| Active | current work, controls, preserved input |
| Working | operation underway, progress or bounded wait, preserved input |
| Proposed | observed material, inference, destination, decision controls |
| Saved | receipt, provenance, status, next useful action |
| Deferred | where the item is parked and how to return |
| Partial | completed bridge, missing bridge, preserved work |
| Blocked | boundary owner, known reason, what remains possible |
| Failed | input preserved, retry path, honest uncertainty |
| Unavailable | scope boundary and alternative path |

## Copy contract

Keep a copy record for important interface text:

```json
{
  "text": "Manifest synchronization is underway. Your draft remains here.",
  "purpose": "explain_waiting_without_alarm",
  "register": "cheerful_infrastructure",
  "epistemic_status": "observed",
  "user_action": "wait_or_leave_and_return",
  "retention": "draft_preserved"
}
```

Do not let a joke obscure the literal state. Do not use emotionally loaded wording to force consent. Do not label a person when describing a system state.

## Runtime and platform rules

- Keep capture, interpretation, consent, persistence, publication, and export distinct in both UI and contracts.
- Never silently retain, share, or publish user material.
- Preserve input across model, network, platform-review, timeout, and configuration failures whenever technically possible.
- Surface external review or approval as an external boundary; do not imply that the user or the digital intelligence caused the block.
- Keep bearer tokens and server-only credentials out of browser and mobile bundles.
- Make retry, idempotency, timeout, and request status visible enough to recover without duplicate durable actions.
- For Android, treat the app as an embodiment surface over the live runtime; native features may own voice, files, secure storage, and notifications, while runtime continuity remains authoritative.

## Accessibility and dignity

- Atmosphere never carries meaning alone.
- Status uses text and structure in addition to color.
- Reduced motion removes spectacle while preserving state and hierarchy.
- Critical copy remains readable at larger text sizes.
- Touch targets and keyboard paths expose the same choices as the visual design.
- Humor may be omitted in high-stakes states without breaking the journey.

## Completion test

A surface is coherent when a new person can answer without prior knowledge:

- Where am I?
- What is this place for?
- What can I do now?
- What is the system observing or suggesting?
- What will become durable, and who decides?
- Where does unfinished work go?
- What happens if this bridge fails?

If the visual language is beautiful but those answers are unavailable, the surface is not finished.
