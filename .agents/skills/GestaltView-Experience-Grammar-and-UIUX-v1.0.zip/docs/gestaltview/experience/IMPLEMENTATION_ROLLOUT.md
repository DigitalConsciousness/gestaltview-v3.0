# GestaltView Experience Grammar: Implementation Rollout

This is the bridge from the canon to the current runtime and future iterations. It is ordered to reduce drift and avoid redoing the same translation in every product.

## Phase 1 — shared foundation

Apply the token set and shared state language to the existing room primitives:

- `RoomHeaderBar`
- `RoomIdentityHeader`
- `RoomStateBadge`
- `GlassPanel`
- `GlassCard`
- `GVTypography`
- `LoadingSpinner`
- `ErrorBoundary`

Acceptance criteria:

- every room identifies itself and its purpose;
- ready, working, proposed, saved, partial, blocked, failed, and unavailable states have shared structure;
- atmospheric styling never carries meaning alone;
- reduced-motion and large-text paths remain usable.

## Phase 2 — continuity loop

Align Billy and capture around one contract:

```text
capture → interpret → show observed/inferred/proposed → ask permission → preserve receipt → return
```

Primary surfaces:

- `Billy`
- `BillyMarkdown`
- `BillyOnboardingPrompt`
- `BlackboardCompanionChat`
- `UniversalCaptureBar`
- `VoiceInput-Universal`
- `RecapPanel`
- `Scaffold`

Acceptance criteria:

- capture is not silently treated as memory;
- possible threads are visibly proposals;
- “keep here for now” is a first-class path;
- failed requests preserve input and explain recovery;
- receipts show provenance and next action.

## Phase 3 — artifacts and exhibits

Make generated work feel durable and inspectable without turning it into a decorative gallery:

- `ArtifactRenderer`
- `GestaltRenderSurface`
- `InnerWorldArtifact`
- `InnerWorldArtifactGallery`
- `ArtifactExportBar`
- `ProvenanceDisclosure`
- `ValidationWall`

Every artifact should expose title, origin, status, intended use, limitations, relationships, and the next useful action.

## Phase 4 — GATE storefront

Rebuild the new-client journey around:

```text
recognize a need → understand the promise → experience a proof → choose a path → configure relevant details → checkout → guided activation
```

Move tiers, seats, packs, backends, and surfaces behind the meaningful path selection. The storefront should feel like an orientation station, not an implementation wizard.

## Phase 5 — external and mobile surfaces

Apply the same room and state contracts to Insight-Bot and Android:

- external platform review and configuration are explicit boundaries;
- no runtime bearer secret is shipped in a client;
- the app can preserve drafts through network and cold-start failures;
- native voice, file access, notifications, and secure session storage remain platform-owned;
- continuity, retrieval, governance, and artifact authority remain runtime-owned.

## Future surface checklist

Before adding a new module, embodiment, storefront offer, or collaboration, create its profile declaration and answer:

1. What does this hold for the person?
2. What is the first useful receipt?
3. Which existing room and component roles apply?
4. Which tone registers are active?
5. What is observed, inferred, proposed, executed, retained, and shared?
6. What is the safe exit and unfinished-work path?
7. What happens when the runtime or platform boundary fails?
8. Which evidence and review gates apply?

If those answers are not available, the surface is still a concept and should not be presented as a finished implementation.
