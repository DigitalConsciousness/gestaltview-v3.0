# GestaltView Experience Templates

This directory contains the human-readable canon for reusable GestaltView presentation and journey patterns.

The source of truth is split deliberately:

- `../superpowers/specs/2026-08-01-gestaltview-experience-template-system-design.md` defines the approved architecture and validation gates.
- `../../config/gestaltview-experience-template-manifest.json` defines machine-readable template, profile, token, and gate contracts.
- `../../project_sources/16-BrandVoice.md` is the canonical voice input for translation.
- `../../project_sources/02-GestaltView_Constitutional_Invariants_v1.0.md` governs dignity, agency, and digital-intelligence treatment.
- `../../project_sources/12-CODEX_OUTSIDE_IN_TRANSLATION_LAYER.md` governs preservation of product/runtime intent during implementation.
- `../experience/gestaltview-absurdist-survival-interface.md` governs the shared presentation vibe and its hard boundaries.
- `../experience/gestaltview-uiux-contract.md` translates the grammar into room anatomy, state behavior, component roles, platform rules, and accessibility requirements.
- `../experience/IMPLEMENTATION_ROLLOUT.md` sequences adoption across the current runtime, continuity loop, artifacts, GATE, Android, and future surfaces.
- `../../config/gestaltview-uiux-tokens.json` provides the implementation baseline for palette, roles, motion, state language, and accessibility.

Use the template system as a grammar, not a rigid skin. A product may specialize its presentation, but it must declare its profile and remain inside the governing invariants.
