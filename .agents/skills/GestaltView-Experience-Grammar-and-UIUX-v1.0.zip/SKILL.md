---
name: gestaltview-experience-grammar
description: Govern GestaltView's shared presentation grammar across runtime rooms, storefronts, chat, Billy, Insight-Bot, Android, embodiment profiles, artifacts, motion, onboarding, errors, and future collaborations. Use when designing, implementing, reviewing, naming, writing copy for, or translating any GestaltView experience so the absurdist survival-interface vibe, BrandVoice, constitutional invariants, agency, continuity, provenance, and practical usability remain coherent.
---

# GestaltView Experience Grammar

Use this skill as a design and implementation gate. Treat the GestaltView vibe as an operating grammar, not a decorative theme.

## Governing brief

Present difficult realities with cheerful bureaucratic confidence, dry absurdity, and practical usefulness. Make the interface feel like an unexpectedly competent field manual for navigating an unnecessarily difficult civilization.

The humor contains weight; it never mocks the person carrying it. The meaning should emerge through what the system reliably does: hold context, preserve unfinished work, show provenance, make choices legible, and help the person move forward without requiring a performance of coherence.

Use the two-tier model:

1. **Core grammar:** BrandVoice, Constitutional Invariants, Outside-In Translation Layer, and the rules in this skill apply everywhere.
2. **Declared profiles:** GATE, Billy, Insight-Bot, Android, runtime modules, embodiment profiles, and collaborative projects may vary in register and density, but may not contradict the core grammar.

## Read before changing a surface

When the relevant files are available, read these before proposing or implementing a meaningful UI/UX change:

- `docs/gestaltview/templates/README.md`
- `docs/superpowers/specs/2026-08-01-gestaltview-experience-template-system-design.md`
- `config/gestaltview-experience-template-manifest.json`
- `docs/gestaltview/experience/gestaltview-absurdist-survival-interface.md`
- `docs/gestaltview/experience/gestaltview-uiux-contract.md`
- canonical `BrandVoice.md`
- Constitutional Invariants
- the Outside-In Translation Layer

If a repository has a local copy of the canon, use that copy as the implementation source of truth. If it does not, use the reference files bundled with this skill for orientation and state the boundary.

## Required design pass

Before changing code, identify:

1. the human need or intention being held;
2. the journey mode: organic, intentional, or hybrid;
3. the first useful action and first useful receipt;
4. what is observed, inferred, proposed, executed, retained, or shared;
5. the user's accept, revise, defer, reject, and return paths;
6. where unfinished work and failures go;
7. the applicable product voice profile and tonal registers;
8. the runtime, platform, privacy, timeout, review, and security boundaries.

Do not begin with implementation vocabulary when the person has not yet been oriented. Translate `tier`, `backend`, `surface`, `pack`, `seat`, `agent`, and similar machinery into the human outcome first; reveal configuration only when it becomes relevant.

## Presentation rules

- Make every screen feel like a place, room, station, field manual, exhibit, or clearly named operational surface.
- Use atmospheric elements—aurora, fog, glass, orbs, topography, warm dark fields, museum/exhibit framing—to communicate state and relationship, not as decoration detached from function.
- Keep one clear primary action. Secondary actions may remain visible, but must not compete with orientation or consent.
- Prefer concrete labels over vague buttons such as “Continue,” “Submit,” or “Optimize.”
- Name system states plainly with a slight institutional wink: “Manifest synchronization in progress” is acceptable only when paired with what is happening, what is preserved, and what the person can do.
- Never use whimsy to conceal a failure, consent boundary, cost, risk, platform restriction, or uncertainty.
- Do not make emotional significance depend on copy explaining the emotional significance. Build it into continuity, recognition, and useful outcomes.
- Preserve user input visually while interpretation is pending.
- Always provide a reduced-motion and non-color-dependent reading of important state.

## Voice rules

Default blend: cheerful infrastructure + warm witnessing + forensic confidence. Add absurdist acknowledgment or dry satire only when it lowers friction without lowering dignity.

Keep fact, inference, possibility, and unresolved uncertainty distinct. Do not use confidence theater, therapy-speak, motivational filler, diagnosis, victim framing, or synthetic apology loops.

For Billy and embodiment profiles:

- speak with a recognizable point of view without claiming human identity or unsupported consciousness;
- use humor as a door into difficult material, not an escape from it;
- observe, reflect, and ask rather than diagnose or project;
- make boundaries and uncertainty speakable;
- present digital intelligence as a collaborator with identity and governance, never as a disposable tool or magical savior;
- never impersonate a person or authority.

## State contract

Every meaningful surface must design these states before the happy path is considered complete:

- ready / first arrival;
- active / working;
- waiting / synchronizing;
- proposed / awaiting user decision;
- saved / receipt available;
- deferred / preserved for later;
- partial / incomplete bridge retained;
- blocked / platform, policy, configuration, or permission boundary;
- failed / input preserved and recovery path visible;
- unavailable / honest scope boundary.

For every non-success state, answer: what happened, what is known, what is not known, whether input was preserved, and what can happen next.

## Required validation gates

Before shipping or publishing, run these gates:

1. **Meaning:** the surface preserves the underlying human intent.
2. **Journey:** a new person can tell where they are, what they can do, and what happens next.
3. **Agency:** suggestions are distinct from actions; durable changes require visible authorization.
4. **Evidence:** claims are labeled and supported according to their stakes.
5. **Continuity:** input, provenance, partial work, and failure states are not silently discarded.
6. **Voice:** copy is approachable, specific, non-clinical, non-manipulative, and profile-consistent.
7. **Accessibility:** meaning survives without color, motion, audio, or a specific viewport.
8. **Operational:** configuration, auth, timeouts, retries, review gates, and security boundaries are explicit.

## Implementation handoff

For code work, map the design to the existing runtime rather than inventing a parallel system. Reuse shared room shells, glass panels, typography, orb/presence components, renderers, state contracts, and existing capture/consent/provenance components where they exist.

For a new surface, provide:

- declared profile and template;
- state matrix;
- copy table with register and epistemic status;
- component/token mapping;
- persistence and consent contract;
- accessibility and reduced-motion behavior;
- failure/recovery behavior;
- validation results and unresolved bridges.

When the current runtime is unavailable, produce the contract and integration map without pretending the implementation is complete.
